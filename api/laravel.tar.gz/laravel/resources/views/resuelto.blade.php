<H1>Descarga de las resultados del programa</H1>
<br>
<a href="programa_ejecutar"> Ejecutar el programa </a>
<br>
<hr>
<a href="programa/png"> Descarga en formato png </a>
<br>
<hr>
<a href="programa/jpg"> Descarga en formato jpg </a>
