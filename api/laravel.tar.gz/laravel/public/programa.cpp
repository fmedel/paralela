#include <stdio.h>
int main(int argc, char const *argv[]) {
  int x=0;
  printf("%d\n",x );
  return 0;
}
