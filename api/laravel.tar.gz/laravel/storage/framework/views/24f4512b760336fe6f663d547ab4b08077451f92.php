<br>
<h1>Api rest  para el proyecto de computacion paralela UTEM</h1>
<br>
<h2>Rutas</h2>
<ul class="list-group">
  <li class="list-group-item">
    programa
  </li>
    <li class="list-group-item">
    programa_ejecutar
  </li>
  <li class="list-group-item">
    programa/png
  </li>
  <li class="list-group-item">
    programa/jpg
  </li>
  <li class="list-group-item">
  laberinto/{sec_fila}/{sec_columna}
  </li>
  <li class="list-group-item">
  laberinto/{sec_fila}/{sec_columna}/{fila}
  </li>
  <li class="list-group-item">
  laberinto/{sec_fila}/{sec_columna}/{fila}/{columna}
</li>
  <li class="list-group-item">
  laberinto_c/{sec_fila}/{sec_columna}
  </li>
  <li class="list-group-item">
  laberinto_c/{sec_fila}/{sec_columna}/{fila}
  </li>
  <li class="list-group-item">
  laberinto_c/{sec_fila}/{sec_columna}/{fila}/{columna}
  </li>
  <li class="list-group-item">
  laberinto_c/{sec_fila}/{sec_columna}/{fila}/{columna}/{filaf}
  </li>
  <li class="list-group-item">
  laberinto_c/{sec_fila}/{sec_columna}/{fila}/{columna}/{filaf}/{columnaf}
  </li>
  <li class="list-group-item">
    user/{user}/{pass}
  </li>
</ul>
