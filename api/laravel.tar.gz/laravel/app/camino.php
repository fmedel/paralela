<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class camino extends Model
{
  protected $table = 'public.camino';
  protected $fillable = ['inicio_fila', 'fin_fila','inicio_columna','fin_columna','solucion','camino','seccion_fila','seccion_columna'];
  protected $guarded = ['id_camino'];
}
