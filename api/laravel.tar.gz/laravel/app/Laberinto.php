<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Laberinto extends Model
{
  protected $table = 'public.laberinto';
  protected $fillable = ['fila', 'columna','valor','seccion_fila','seccion_columna'];
  protected $guarded = ['id_laberinto'];
}
