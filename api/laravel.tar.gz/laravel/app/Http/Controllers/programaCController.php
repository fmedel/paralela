<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


class programaCController extends Controller
{

  public function ejecutar(){
    $result = exec("./tarea_programa");
    return \Response::json(['programa_status' => $result,
                            'status' => '200'], 200);
  }

  public function png(){
    $pathtoFile = public_path().'/m.png';
    return response()->download(public_path().'/m.png');
  }

  public function jpg(){
    $pathtoFile = public_path().'/m.jpg';
    return response()->download($pathtoFile);
  }

}
