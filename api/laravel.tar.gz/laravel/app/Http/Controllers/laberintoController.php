<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Laberinto as Laberinto;

class laberintoController extends Controller
{
  public function seccion($seccion_fila,$seccion_columna){
    if (!is_numeric($seccion_fila) or !is_numeric($seccion_columna)) {
      return \Response::json(['table' => 'asignacion',
                              'data'=> 'Error en el parametro no es numerico ',
                              'status' => '400'], 200);
    }
    $arreglo = Laberinto::where([['seccion_fila','=',$seccion_fila],['seccion_columna','=',$seccion_columna]])->limit(1000)->get();
    if (count($arreglo)>=1) {
      return \Response::json(['table' => 'asignacion',
                              'data' => $arreglo,
                              'status' => '200'], 200);
    } else {
      return \Response::json(['table' => 'asignacion',
                              'data'=> 'No se encuentra la asignacion en bd',
                              'status' => '204'], 200);
    }

  }
  public function fila($seccion_fila,$seccion_columna,$fila){
    if (!is_numeric($seccion_fila) or !is_numeric($seccion_columna) or !is_numeric($fila)) {
      return \Response::json(['table' => 'asignacion',
                              'data'=> 'Error en el parametro no es numerico ',
                              'status' => '400'], 200);
    }
    $arreglo = Laberinto::where([['seccion_fila','=',$seccion_fila],['seccion_columna','=',$seccion_columna],['fila','=',$fila]])->get();
    if (count($arreglo)>=1) {
      return \Response::json(['table' => 'asignacion',
                              'data' => $arreglo,
                              'status' => '200'], 200);
    } else {
      return \Response::json(['table' => 'asignacion',
                              'data'=> 'No se encuentra la asignacion en bd',
                              'status' => '204'], 200);
    }
  }
  public function columna_f($seccion_fila,$seccion_columna,$fila,$columna){
    if (!is_numeric($seccion_fila) or !is_numeric($seccion_columna) or !is_numeric($fila) or !is_numeric($columna)) {
      return \Response::json(['table' => 'asignacion',
                              'data'=> 'Error en el parametro no es numerico ',
                              'status' => '400'], 200);
    }
    $arreglo = Laberinto::where([['seccion_fila','=',$seccion_fila],['seccion_columna','=',$seccion_columna],['fila','=',$fila],['columna','=',$columna]])->get();
    if (count($arreglo)>=1) {
      return \Response::json(['table' => 'asignacion',
                              'data' => $arreglo,
                              'status' => '200'], 200);
    } else {
      return \Response::json(['table' => 'asignacion',
                              'data'=> 'No se encuentra la asignacion en bd',
                              'status' => '204'], 200);
    }
  }
  public function seccion_simple($seccion_fila,$seccion_columna){
    if (!is_numeric($seccion_fila) or !is_numeric($seccion_columna)) {
      return \Response::json(['data'=> 'Error en el parametro no es numerico ',
                              'status' => '400'], 200);
    }
    $arreglo = Laberinto::where([['seccion_fila','=',$seccion_fila],['seccion_columna','=',$seccion_columna]])->select('valor')->get();
    if (count($arreglo)>=1) {
      return \Response::json($arreglo, 200);
    } else {
      return \Response::json([
                              'data'=> 'No se encuentra la asignacion en bd',
                              'status' => '204'], 200);
    }

  }

}
