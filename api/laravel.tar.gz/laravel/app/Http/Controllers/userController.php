<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\user as User;

class userController extends Controller
{
    public function ingreso($user,$pass){
      $arreglo = User::where([['user_t','like',$user],['password_t','like',$pass]])->get();
      if (count($arreglo)>=1) {
        return \Response::json(['ingreso' => 'true',
                                'status' => '200'], 200);
      } else {
        return \Response::json(['ingreo'=> 'false',
                                'status' => '204'], 200);
      }
    }
}
