<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class user extends Model
{
  protected $table = 'public.user';
  protected $fillable = ['user_t', 'password_t'];
  protected $guarded = ['id_user'];
}
