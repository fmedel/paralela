<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('404', function () {return view('404');});
Route::get('/', function () {return view('welcome');});

/********************* rutas del programa *******************************/
Route::get('programa',function(){return view('resuelto');});
Route::get('programa_ejecutar','programaCController@ejecutar');
Route::get('programa/png','programaCController@png');
Route::get('programa/jpg','programaCController@jpg');

/********************* rutas del laberinto *******************************/
Route::get('laberinto/{sec_fila}/{sec_columna}','laberintoController@seccion');
Route::get('laberinto_s/{sec_fila}/{sec_columna}','laberintoController@seccion_simple');
Route::get('laberinto/{sec_fila}/{sec_columna}/{fila}','laberintoController@fila');
Route::get('laberinto/{sec_fila}/{sec_columna}/{fila}/{columna}','laberintoController@columna_f');
/********************* rutas del camino   *******************************/
Route::get('laberinto_c/{sec_fila}/{sec_columna}','caminoController@seccion');
Route::get('laberinto_c/{sec_fila}/{sec_columna}/{fila}','caminoController@fila');
Route::get('laberinto_c/{sec_fila}/{sec_columna}/{fila}/{columna}','caminoController@columna_f');
Route::get('laberinto_c/{sec_fila}/{sec_columna}/{fila}/{columna}/{filaf}','caminoController@fila_fin');
Route::get('laberinto_c/{sec_fila}/{sec_columna}/{fila}/{columna}/{filaf}/{columnaf}','caminoController@columna_fin');
/********************* USER ***********************************/
Route::get('user/{user}/{pass}','userController@ingreso');
