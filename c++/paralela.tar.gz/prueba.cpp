#include <omp.h>
#include <iostream>
#include <time.h>
using namespace std;
int main(int argc, char const *argv[]) {
  clock_t start, end;
  start = clock();
  cout<<omp_get_num_procs()<<"\n";
  int z=0;
  #pragma omp parallel for
  for(int i=0; i<4000; ++i){
    for(int j=0; j<4000; ++j){
      z=i+j;
      std::cout << i <<","<< j<<'\n';
      }
    }
    end = clock();
  //cout<< (end - start) / 1000<<"\n";
  return 0;
}
