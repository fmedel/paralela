# cpyd172-g3
Carpeta contenedora del front-end
 libreria exta

sudo apt-get install libpqxx-dev
compilar con  -lpqxx -lpq
