gcc  main.c -o PngaPixcel -lpng
./PngaPixcel
